#include <stdio.h>
int main()
{
    
    int i, j, row = 0, col = 0;
    int mat[3][3];
    printf("Enter the value for m:-");
    scanf("%d",&row);
    printf("Enter the value for n:-");
    scanf("%d", &col);
          printf("Enter the elements for %d*%d matrix of =\n",row,col);
          for (i = 0; i <row; i++)
          {
              for (j = 0; j < col; j++)
              {
                  scanf("%d", &mat[i][j]);
              }
          }
          
          printf("Elements of %d*%d Matrix is\n",row,col);
          for (i = 0; i < row; i++)
          {
              for (j = 0; j < col; j++)
              {
                  printf("%d\t", mat[i][j]);
              }
              printf("\n");
          }
          
          for (i = 0; i < row; i++)
          {
              printf("\n");
              for (j = 0; j < col; j++)
              {
                  if (i >= j)
                  {
                      printf("%d", mat[i][j]);
                  }
                  else
                  {
                      printf("\t");
                  }
              }
              
          }
          printf("\n");
          return 0;
          }

