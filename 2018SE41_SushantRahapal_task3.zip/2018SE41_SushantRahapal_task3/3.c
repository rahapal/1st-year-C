#include<stdio.h>
int main()
{
    char word[11]={"ENGINEERING"};
    int i,j,len=0;
    while(word[len]!='\0')
    {
        len++;
    }
    for(i=0;i<len;i++)
    {
        for(j=0;j<i;j++)
        {
            printf("%c",word[j]);
        }
        printf("\n");
    }
}
