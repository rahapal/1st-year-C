#include<stdio.h>
int main()
{
    int sus[100];
    int n,i,s=0,l=0;
    printf("How many numbers do you wan to enter[Max 100]?=");
    scanf("%d",&n);
    printf("Enter the %d number:-\n",n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&sus[i]);
    }
    s=sus[0];
    l=sus[0];
    for(i=0; i<n; i++)
    {
        
        if(sus[i] > l)
        {
            l = sus[i];
        }
        
      
        if(sus[i] < s)
        {
            s = sus[i];
        }
    }
    printf("Smallest number=%d\nLargest number=%d",s,l);
    
}
