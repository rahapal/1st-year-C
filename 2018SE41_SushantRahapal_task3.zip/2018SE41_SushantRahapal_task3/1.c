#include<stdio.h>
int main()
{
    int mat[3][3];
    int i,j,sume=0;
    printf("Enter the element for the 3*3 matrix:-\n");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&mat[i][j]);
        }
    }
    printf("The elements in the matrix:-\n");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%4d",mat[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            if(mat[i][j] %2 == 0)
            {
                sume +=mat[i][j];
            }
        }
       
    }
    printf("Total sum of the even numbers:-%d",sume);
    return 0;
}
